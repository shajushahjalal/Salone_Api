<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalonRegistration extends Model
{
    //
    protected $table = "salon_registration";
    public $timestamps = false;
}
