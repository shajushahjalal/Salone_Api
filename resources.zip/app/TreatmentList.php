<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TreatmentList extends Model
{
    //
    protected $table = "treatment_list";
    public $timestamps = false;
    
}
