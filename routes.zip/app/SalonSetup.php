<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalonSetup extends Model
{
    //
    protected $table = "salon_setup";
}
